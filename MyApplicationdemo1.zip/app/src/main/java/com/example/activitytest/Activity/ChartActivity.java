package com.example.activitytest.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.activitytest.R;
import com.example.activitytest.util.CustomMPLineChartMarkerView;
import com.example.activitytest.util.MhhUtils;
import com.example.activitytest.util.chart_util;
import com.github.mikephil.charting.charts.LineChart;

public class ChartActivity extends AppCompatActivity {

    private LineChart chart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chart_layout);

        chart = (LineChart) findViewById(R.id.mChart);  //获取对象
        chart_util.chart_init(chart);                   //初始化折线图

        //点击显示文本
        CustomMPLineChartMarkerView mv_time = new CustomMPLineChartMarkerView(this);
        mv_time.setChartView(chart);
        chart.setMarker(mv_time);

        MhhUtils.dataShowByMhh(chart);
//        MhhUtils.dataShowByMhh2(chart);
    }

    /*退出时取消绑定服务以及广播监听*/
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}