package com.example.activitytest.Activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.example.activitytest.BaseActivity
import com.example.activitytest.R
import com.example.activitytest.databinding.FirstLayoutBinding
import com.example.activitytest.util.CustomMPLineChartMarkerView
import com.example.activitytest.util.MhhUtils
import com.example.activitytest.util.chart_util
import com.github.mikephil.charting.charts.LineChart

class FirstActivity : BaseActivity() {

    private lateinit var chart: LineChart

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.first_layout)
        Log.d("FirstActivity", "Task id is $taskId")
        Log.d("FirstActivity", javaClass.simpleName + " itself go")
        //使用ViewBinding获取实例
        val binding = FirstLayoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        chart = binding.mChart							//获取对象
        chart_util.chart_init(chart)					//初始化——时域图
        MhhUtils.dataShowByMhh(chart)
        val mvTime = CustomMPLineChartMarkerView(this)
        mvTime.chartView = chart
        chart.marker = mvTime

        MhhUtils.dataShowByMhh2(chart)

        binding.button1.setOnClickListener {
            SecondActivity.actionStart(this, "NB", "666")
        }
    }

    //重写onActivityResult()
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            1 -> if (resultCode == RESULT_OK) {
                val returnedData = data?.getStringExtra("data_return")
                Log.d("FirstActivity", "returned data is $returnedData")
            }
        }
    }

    //menu的demo用例
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.add_item -> Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
            R.id.remove_item -> Toast.makeText(this, "Remove clicked", Toast.LENGTH_SHORT).show()
        }
        return true
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    companion object {
        fun actionStart(context: Context) {
            val intent = Intent(context, FirstActivity::class.java)
            context.startActivity(intent)
        }
    }
}