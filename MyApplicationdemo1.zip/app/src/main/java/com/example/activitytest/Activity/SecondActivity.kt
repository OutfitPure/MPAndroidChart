package com.example.activitytest.Activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.example.activitytest.BaseActivity
import com.example.activitytest.databinding.SecondLayoutBinding
import com.example.activitytest.util.CustomMPLineChartMarkerView
import com.example.activitytest.util.MhhUtils
import com.example.activitytest.util.barChart_util
import com.example.activitytest.util.chart_util
import com.github.mikephil.charting.charts.BarChart


class SecondActivity : BaseActivity() {
    private lateinit var barChart: BarChart

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = SecondLayoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        barChart = binding.mBarChart
        barChart_util.chart_init(barChart)
        val mvFrequence = CustomMPLineChartMarkerView(this)
        mvFrequence.chartView = barChart
        barChart.marker = mvFrequence

        MhhUtils.barChartTry(barChart)

        Log.d("SecondActivity", "Task id is $taskId")
        binding.button2.setOnClickListener {
            ThirdActivity.actionStart(this)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onBackPressed() {
        val intent = Intent()
        intent.putExtra("data_return", "Hello FirstActivity HERE IS BACK BUTTON")
        setResult(RESULT_OK, intent)
        finish()
    }
    companion object {
        fun actionStart(context: Context, data1: String, data2: String) {
            val intent = Intent("com.example.activitytest.ACTION_START")
            intent.addCategory("mhhjj18cm")
            //val intent = Intent(context, SecondActivity::class.java)
            intent.putExtra("param1", data1)
            intent.putExtra("param2", data2)
            context.startActivity(intent)
        }
    }
}