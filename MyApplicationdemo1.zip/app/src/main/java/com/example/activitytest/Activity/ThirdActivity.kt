package com.example.activitytest.Activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.example.activitytest.BaseActivity
import com.example.activitytest.databinding.ThirdLayoutBinding

class ThirdActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ThirdLayoutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Log.d("ThirdActivity", "Task id is $taskId")
        binding.button3.setOnClickListener {
            val intent = Intent(this, ChartActivity::class.java);
            startActivity(intent);
        }
    }

    companion object {
        fun actionStart(context: Context) {
            val intent = Intent("a.special.start.mhh")
            intent.putExtra("data_return", "Hello ThirdActivity")
            context.startActivity(intent)
        }
    }
}