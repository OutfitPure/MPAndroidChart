package com.example.activitytest;
import android.database.Cursor;

import com.example.activitytest.DeviceData;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * @Classname DBUtil
 * @Description TODO
 * @Date 2021/7/19 10:00
 * @Created by DELL
 */ // 工具类，负责对数据库查询后返回的Cursor进行解析
public class DBUtil {
    // 单例类
    private static DBUtil dbUtil;

    private DBUtil() {
    }

    public static DBUtil getInstance() {
        if (dbUtil == null) {
            dbUtil = new DBUtil();
        }
        return dbUtil;
    }



    /**
     * 从 Cursor 对象中获取到 DeviceData 对象
     *
     * @param device_data Cursor 对象
     * @return DeviceData对象的List集合
     * @author zzz
     */
    @NotNull
    public List<DeviceData> getDeviceData(Cursor device_data) {
        // 声明一个List，用来存储DeviceData对象
        List<DeviceData> deviceDataList = new ArrayList<>();
        if (device_data.moveToFirst()) {
            do {
                // 获取Number
                Integer number = device_data.getInt(device_data.getColumnIndex(DeviceData.Number));
                // 获取time
                Long time = device_data.getLong(device_data.getColumnIndex(DeviceData.Time));
                // 获取deviceName
                String deviceName = device_data.getString(device_data.getColumnIndex(DeviceData.DeviceName));
                // 获取数据
                String data = device_data.getString(device_data.getColumnIndex(DeviceData.Data));
                /*
                    //对该字符的解析
                    // 去掉首尾的[]
                    String substring = data2String.substring(1, data2String.length() - 2);
                    // 以 , 将其分割开
                    String[] split = substring.split(",");
                    // 使用datas存储
                    List<Float> datas = new ArrayList<>();

                    // 转换为Float类型的
                    for (String data : datas) {
                        datas.add( Float.valueOf(data));
                    }
                    // 下面是简化写法
                 */
                // 对数据进行解析
                List<Float> datas = new ArrayList<>();
                for (String s : data.substring(1, data.length() - 1).split(",")) {
                    datas.add(Float.valueOf(s));
                }
                // 获取状态
                Integer state = device_data.getInt(device_data.getColumnIndex(DeviceData.State));
                // List中新增项
                deviceDataList.add(new DeviceData(number, time, deviceName, datas, state));
            } while (device_data.moveToNext());
        }
        // 返回获取到的DeviceData类的List对象
        return deviceDataList;
    }
}
