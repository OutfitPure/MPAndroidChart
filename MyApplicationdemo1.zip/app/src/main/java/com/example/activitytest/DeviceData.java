package com.example.activitytest;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class DeviceData {
    // 对应于数据库中表的字段名
    public static final String Number = "number";
    public static final String Time = "time";
    public static final String DeviceName = "device_name";
    public static final String Data = "data";
    public static final String State = "state";


    private Integer number;
    private Long time;
    private String deviceName;
    private List<Float> datas;
    private Integer state;

    public DeviceData(){}

    public DeviceData(Integer number,Long time,String deviceName,List<Float> datas,Integer state){
        this.number = number;
        this.time = time;
        this.deviceName = deviceName;
        this.datas = datas;
        this.state = state;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public List<Float> getDatas() {
        return datas;
    }

    public void setDatas(List<Float> datas) {
        this.datas = datas;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    @NotNull
    @Override
    public String toString() {
        return "DeviceData{" +
                "number=" + number +
                ", time=" + time +
                ", deviceName='" + deviceName + '\'' +
                ", datas=" + datas +
                ", state=" + state +
                '}';
    }
}
