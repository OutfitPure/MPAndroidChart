package com.example.activitytest.util;

import android.graphics.Color;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;


import java.util.ArrayList;
import java.util.List;

public class barChart_util {
    /**
     * 完成频域 Chart 的初始化
     * @param chart 传入一个需要初始化的 Chart
     */
    public static void chart_init(BarChart chart) {
        //chart.setOnChartValueSelectedListener(this);
        // enable description text
        chart.getDescription().setEnabled(true);
        // enable touch gestures
        chart.setTouchEnabled(true);

        /****************设置描述信息*************/
        Description description = new Description();
        description.setText("description here");
        description.setPosition(700, 35);
        description.setTextColor(0xff9966FF);                   //淡紫色——描述 description 字体颜色
        description.setTextSize(20);
        chart.setDescription(description);                      //设置图表描述信息
        chart.setNoDataText("No chart data available! Try to figure it.");                        //没有数据时显示的文字
        chart.setNoDataTextColor(Color.BLACK);                    //没有数据时显示文字的颜色
        chart.setDrawGridBackground(false);                     //chart 绘图区后面的背景矩形将绘制
        chart.setDrawBorders(true);                            //绘制图表边框的线
        chart.setFitBars(true);

        // enable scaling and dragging
        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);
        chart.setDrawGridBackground(false);

        //set chart 动画~
        //chart.animateX(8000);

        // if disabled, scaling can be done on x- and y-axis separately
        chart.setPinchZoom(false);

        // set an alternative background color
        //chart.setBackgroundColor(0x4169E1FF);

        BarData data = new BarData();
        data.setValueTextColor(Color.BLACK);

        // add empty data
        chart.setData(data);

        // get the legend (only possible after setting data)
        Legend l = chart.getLegend();

        // modify the legend ...
        l.setForm(Legend.LegendForm.LINE);
        l.setTextColor(Color.BLACK);
        //x轴配置
        XAxis xl = chart.getXAxis();
        //xl.setTypeface(tfLight);
        xl.setTextColor(Color.BLACK);
        xl.setDrawGridLines(false);
        xl.setAvoidFirstLastClipping(true);
        xl.setEnabled(true);
        xl.setPosition(XAxis.XAxisPosition.BOTTOM);               //X轴文字显示位置
        //左y轴配置
        YAxis leftAxis = chart.getAxisLeft();
        leftAxis.setTextColor(Color.BLACK);
        leftAxis.setAxisMaximum(30f);
        leftAxis.setAxisMinimum(0f);
        leftAxis.setDrawGridLines(true);
        leftAxis.setDrawZeroLine(true);
        //右y轴配置
        YAxis rightAxis = chart.getAxisRight();
        rightAxis.setEnabled(false);
    }

    /**
     * 给频域 Chart 添加数据
     * @param chart 传入需要添加数据的 Chart
     * @param fftData 频域数据
     */

    public static void addEntry(BarChart chart, List<Float> fftData) {
        List<BarEntry> barEntries = new ArrayList<>();
        YAxis leftAxis = chart.getAxisLeft();
        for (int index = 0; index < fftData.size(); index++) {
            barEntries.add(new BarEntry( (float) index, fftData.get(index) ));
        }
        BarDataSet iBarDataSet = createBarDataSet(chart, barEntries);

        BarData barData = new BarData(iBarDataSet);
        barData.setBarWidth(0.9f);
        leftAxis.setAxisMaximum(barData.getYMax() + 1);
        leftAxis.setAxisMinimum(barData.getYMin() - 1);
        chart.setData(barData);
        chart.notifyDataSetChanged();
        chart.invalidate();
        chart.setVisibleXRangeMaximum(128);                //设置一次最多显示的数据个数
        chart.moveViewToX(barData.getEntryCount());
    }

    public static BarDataSet createBarDataSet(BarChart chart, List<BarEntry> barEntries) {

        BarDataSet iBarDataSet = new BarDataSet(barEntries, chart.getDescription().getText() + " Data");

        YAxis leftAxis = chart.getAxisLeft();

        iBarDataSet.setAxisDependency(YAxis.AxisDependency.LEFT);
        //条形的颜色
        iBarDataSet.setColor(0xff4B0082);
        iBarDataSet.setDrawValues(false);       //默认不显示 数值
        iBarDataSet.setValueTextColor(0xffAD009F);
        iBarDataSet.setValueTextSize(9f);
        //填充

        //高亮颜色
        iBarDataSet.setHighLightColor(0xffAD009F);
        iBarDataSet.setDrawValues(true);

        return iBarDataSet;
    }
}
