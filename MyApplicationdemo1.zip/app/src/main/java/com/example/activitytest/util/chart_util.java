package com.example.activitytest.util;

import android.graphics.Color;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;



public class chart_util {
    public static void chart_init(LineChart chart) {
        //chart.setOnChartValueSelectedListener(this);
        // enable description text
        chart.getDescription().setEnabled(true);
        // enable touch gestures
        chart.setTouchEnabled(true);

        /****************设置描述信息*************/
        Description description = new Description();
        description.setText("description here");
        description.setPosition(700, 35);
        description.setTextColor(0xff9966FF);                   //淡紫色——描述 description 字体颜色
        description.setTextSize(20);
        chart.setDescription(description);                      //设置图表描述信息
        chart.setNoDataText("No chart data available! Try to figure it.");                        //没有数据时显示的文字
        chart.setNoDataTextColor(Color.BLACK);                    //没有数据时显示文字的颜色
        chart.setDrawGridBackground(false);                     //chart 绘图区后面的背景矩形将绘制
        chart.setDrawBorders(true);                            //绘制图表边框的线
        // enable scaling and dragging
        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);
        chart.setDrawGridBackground(false);

        //set chart 动画~
        //chart.animateX(8000);

        // if disabled, scaling can be done on x- and y-axis separately
        chart.setPinchZoom(false);

        // set an alternative background color
        //chart.setBackgroundColor(0x4169E1FF);

        LineData data = new LineData();
        data.setValueTextColor(Color.BLACK);

        // add empty data
        chart.setData(data);

        // get the legend (only possible after setting data)
        Legend l = chart.getLegend();

        // modify the legend ...
        l.setForm(Legend.LegendForm.LINE);
        l.setTextColor(Color.BLACK);
        //x轴配置
        XAxis xl = chart.getXAxis();
        //xl.setTypeface(tfLight);
        xl.setTextColor(Color.BLACK);
        xl.setDrawGridLines(false);
        xl.setAvoidFirstLastClipping(true);
        xl.setEnabled(true);
        xl.setPosition(XAxis.XAxisPosition.BOTTOM);               //X轴文字显示位置
        //左y轴配置
        YAxis leftAxis = chart.getAxisLeft();
        leftAxis.setTextColor(Color.BLACK);
        leftAxis.setAxisMaximum(30f);
        leftAxis.setAxisMinimum(0f);
        leftAxis.setDrawGridLines(true);
        //右y轴配置
        YAxis rightAxis = chart.getAxisRight();
        rightAxis.setEnabled(false);
    }

    public static void addEntry(LineChart chart, float Concentration_data) {
        LineData data = chart.getData();
        YAxis leftAxis = chart.getAxisLeft();
        if (data != null) {
            ILineDataSet set = data.getDataSetByIndex(0);
            // set.addEntry(...); // can be called as well
            if (set == null) {
                set = createSet(chart);
                data.addDataSet(set);
            }

            data.addEntry(new Entry(set.getEntryCount(), Concentration_data), 0);
            leftAxis.setAxisMaximum(data.getYMax() + 1);
            leftAxis.setAxisMinimum(data.getYMin() - 1);

            data.notifyDataChanged();
            chart.notifyDataSetChanged();
            chart.invalidate();
            chart.setVisibleXRangeMaximum(128);                //设置一次最多显示的数据个数
            chart.moveViewToX(data.getEntryCount());
        }
    }

    private static LineDataSet createSet(LineChart chart) {
        LineDataSet set = new LineDataSet(null, chart.getDescription().getText() + " Data");
        set.setAxisDependency(YAxis.AxisDependency.LEFT);
        //线的颜色
        set.setColor(0xff4B0082);
        set.setCircleColor(0xff534ED9);
        set.setLineWidth(2f);
        set.setCircleRadius(4f);

        set.setDrawValues(false);       //默认不显示 数值
        set.setValueTextColor(0xffAD009F);
        set.setValueTextSize(9f);

        //填充
        set.setDrawFilled(true);
        set.setFillAlpha(165);
        set.setFillColor(0xff7673D9);

        //十字线颜色
        set.setHighLightColor(0xffAD009F);

        set.setDrawValues(true);
        return set;
    }
}
